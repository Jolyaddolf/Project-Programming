﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassAvto
{
   
   
        class Avto
        {
            private string nomer_mashini;
            private float petrol_tank;
            private float consumption;
            private float distance;
            private float speed;
            private float probeg; //пробег
            private double x2;
            private double y2;
            private double S;

            public void Info() //заполнение информации о машине
            {
                Console.Write("Введите номер машины: ");
                nomer_mashini = Console.ReadLine();

                Console.Write("Введите объем бака: ");
                petrol_tank = Convert.ToSingle(Console.ReadLine());

                Console.Write("Введите расход бака: ");
                consumption = Convert.ToSingle(Console.ReadLine());

                Console.Write("Введите пробег автомобиля: ");
                probeg = Convert.ToSingle(Console.ReadLine());

                Random rnd = new Random();
                distance = rnd.Next(1, 3000);
                speed = rnd.Next(10, 300);

            }
            public void output() //вывод информации о машине
            {
                //Console.Clear();
                Console.WriteLine("ИНФОРМАЦИЯ О МАШИНЕ: \n");
                Console.WriteLine($"Номер машины: {nomer_mashini}\nОбъем бака: {petrol_tank}\nРасход бака: {consumption}");
                Console.WriteLine($"Ваше расстояние : {distance} км");
                Console.WriteLine($"Ваша скорость : {speed} км/ч");
                Console.WriteLine($"Ваш пробег: {probeg} км");
                Console.WriteLine("______________________________");
                Console.ReadKey();
            }
            public void ezda()
            {
                Console.Clear();
                float kilometers_quantity = ((petrol_tank / consumption)) * 100; //сколько километров можно проехать ///верная
                float necessary_add_in_a_bak = (distance * consumption) / 100 - petrol_tank; //это объем бака с запасом на 100км
                float remains = (distance * consumption) / 100; //сколько останется после поездки

                if (kilometers_quantity > distance) //Формула проверки хватит ли бензина на полездку
                {
                    //Console.WriteLine("Бензина хватит для поездки");
                    Console.WriteLine($"При объеме бака в {petrol_tank} литров, вы сможете проехать {kilometers_quantity} км");
                    Console.WriteLine($"По окончании поездки в баке останется {petrol_tank - remains}");

                    Console.WriteLine();
                    Console.WriteLine("Вы можете ускориться или притормозить. Сделайте свой выбор");
                    Console.Write("1.Разогняться\n2.Затормозить: ");

                    int user_choise = Convert.ToInt32(Console.ReadLine());
                    if (user_choise == 1) //ЕСЛИ ВЫБРАЛИ РАЗОГНАТЬСЯ
                    {
                        gaz();
                    }
                    else
                    {
                        tormoz();
                    }

                    koordinates(); //рассчет расстояния по координатам

                    Console.ReadKey();
                }
                else
                {
                    zapravka_car(kilometers_quantity, necessary_add_in_a_bak);
                }
            }

            public void tormoz()
            {
                Random rnd = new Random();
                speed -= rnd.Next(5, 20); //рандомная скорость

                Console.WriteLine($"\nВаша скорость уменьшилась, теперь она = {speed} км/ч. Вы медленнее!");
            }

            public void gaz()
            {
                Random rnd = new Random();
                speed += rnd.Next(5, 20); //рандомная скорость

                Console.WriteLine($"\nВаша скорость увеличилась, теперь она = {speed} км/ч. Вы едете быстрее ветра!");
            }

            public void zapravka_car(float kilometers_quantity, float necessary_add_in_a_bak)
            {
                Console.WriteLine($"При объеме бака в {petrol_tank} литров, вы сможете проехать {kilometers_quantity} км");
                Console.WriteLine($"Чтобы проехать {distance} км, вам нужно дополнительно залить в бак {necessary_add_in_a_bak} литров");

                Console.Write("Введите количество бензина, которое нужно залить: ");
                int zalit_benzin = Convert.ToInt32(Console.ReadLine());
                petrol_tank += zalit_benzin;

                Console.WriteLine($"В вашем баке теперь {petrol_tank}");

                ezda();
                probeg_distance();
            }

            public void probeg_distance()
            {
                probeg = probeg + distance; // Расчёт общего пробега с учётом пройденного расстояния
                Console.Write($"Теперь пробег машины после пройденного расстояния равен: {probeg}");
                Console.WriteLine();
                Console.ReadKey();
                Console.Clear();
            }

            public void accident(int cars_quantity)
            {
                Random rand = new Random();
                int i = rand.Next(0, cars_quantity);
                int j = rand.Next(0, cars_quantity);

                if (i != j) //если машины не совпадают
                {
                    Console.WriteLine($"Машины {i},{j} попали в аварию!");
                }
                else
                {
                    Console.WriteLine("За сегодня аварий не было!");
                }
            }

            public void koordinates() //вводим координаты и рассчитываем расстояние
            {
                Console.Write("Введите конечную координату по оси Х: ");
                x2 = Convert.ToSingle(Console.ReadLine());

                //теперь рассчитываем по формуле
                S = Math.Sqrt(Math.Pow(x2, 2) + Math.Pow(y2, 2));

                Console.WriteLine($"Расстояние между начальной и конечной точками равно {S}");
            }

        }
    }


